Script and grammar for fuzzing Microsoft jscript.dll JavaScript engine.

Usage is the same as for DOM fuzzing.
