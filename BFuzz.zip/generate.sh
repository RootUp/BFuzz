#!/bin/bash
cd domato
python generator.py --output_dir ../recurve/ --no_of_files 50
